﻿Describe 'Podcast-NoAgenda Module Tests' {

  It "has the root module Podcast-NoAgenda.psm1" {
    "C:\PS\Pester-course\demo\module-02\Podcast-NoAgenda\Podcast-NoAgenda.psm1" | Should Exist
  }
        
}


